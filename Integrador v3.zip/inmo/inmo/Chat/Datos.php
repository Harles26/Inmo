<?php
$server = "localhost";
$username = "root";
$password = "";
$bd = "._BD_INMOBILIARIA";

// Conexión a la base de datos
$conexion = new mysqli($server, $username, $password, $bd);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Consulta SQL para obtener datos de la tabla propiedades
$sql = "SELECT * FROM propiedades";
$resultado = $conexion->query($sql);

// Array para almacenar las propiedades
$propiedades = array();

// Convertir objetos de tipo date a cadenas de texto
while ($fila = $resultado->fetch_assoc()) {
    $fila['fecha_alta'] = date('Y-m-d', strtotime($fila['fecha_alta']));
    $propiedades[] = $fila;
}

// Cerrar conexión
$conexion->close();

// Mostrar el JSON generado
header('Content-Type: application/json');
echo json_encode($propiedades, JSON_PRETTY_PRINT);
?>
