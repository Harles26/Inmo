<?php
session_start();

//Si el usuario no esta logeado lo enviamos al login
if (!(isset($_SESSION['usuarioLogeado']) && $_SESSION['usuarioLogeado'] != '')) {
    header("Location: login.php");
}

include("funciones.php");

//con la función obtenerTotalRegistros obtengo el total de registros de una tabla
// el nombre de la tabla lo mando por paramaetro
$totalPropiedades = obtenerTotalRegistros('propiedades');
$totalTipos = obtenerTotalRegistros('tipos');
$totalPaises = obtenerTotalRegistros('paises');
$totaCiudades = obtenerTotalRegistros('ciudades');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="estilo.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Nexo - Admin</title>
</head>

<body>
    <div id="contenedor-admin">
        <?php include("contenedor-menu.php"); ?>

        <div class="contenedor-principal">
            <div id="dashboard">
                <h2>Dashboard</h2>
                <hr>
                <div class="contenedor-cajas-info">
                    <div class="caja-info propiedades">
                        <p>Total Propiedades</p>
                        <hr>
                        <span class="dato"> <?php echo $totalPropiedades ?></span>
                        <hr>
                        <a href="listado-propiedades.php">Ver Detalles</a>
                    </div>
                    <div class="caja-info tipo">
                        <p>Total Tipo de Propiedades</p>
                        <hr>
                        <span class="dato"> <?php echo $totalTipos ?></span>
                        <hr>
                        <a href="listado-tipo-propiedades.php">Ver Detalles</a>
                    </div>
                    <div class="caja-info paises">
                        <p>Total Países</p>
                        <hr>
                        <span class="dato"><?php echo $totalPaises ?></span>
                        <hr>
                        <a href="listado-paises.php">Ver Detalles</a>
                    </div>
                    <div class="caja-info ciudades">
                        <p>Total Ciudades</p>
                        <hr>
                        <span class="dato"><?php echo $totaCiudades ?></span>
                        <hr>
                        <a href="listado-ciudades.php">Ver Detalles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<style>

</style>

</html>

<script>
window.addEventListener('mouseover', initLandbot, { once: true });
window.addEventListener('touchstart', initLandbot, { once: true });
var myLandbot;
function initLandbot() {
  if (!myLandbot) {
    var s = document.createElement('script');s.type = 'text/javascript';s.async = true;
    s.addEventListener('load', function() {
      var myLandbot = new Landbot.Livechat({
        configUrl: 'https://storage.googleapis.com/landbot.online/v3/H-2538957-YBXEVFOZWKMSPCQJ/index.json',
      });
    });
    s.src = 'https://cdn.landbot.io/landbot-3/landbot-3.0.0.js';
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);
  }
}
</script>