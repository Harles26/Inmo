<?php
// funciones.php

// Función para obtener la configuración
function obtenerConfiguracion($conn) {
    $query = "SELECT * FROM configuracion WHERE id = 1";
    $result = mysqli_query($conn, $query);
    if (!$result || mysqli_num_rows($result) == 0) {
        return null;
    }
    return mysqli_fetch_assoc($result);
}

// Función para agregar un nuevo tipo de propiedad
function agregarNuevoTipoDePropiedad($conn, $nombreTipo) {
    $nombreTipo = mysqli_real_escape_string($conn, $nombreTipo);
    $query = "INSERT INTO tipos (nombre_tipo) VALUES ('$nombreTipo')";
    if (mysqli_query($conn, $query)) {
        return "Tipo de propiedad '$nombreTipo' agregado correctamente";
    } else {
        return "Error al agregar tipo de propiedad: " . mysqli_error($conn);
    }
}

// Función para agregar un nuevo país
function agregarNuevoPais($conn, $nombrePais) {
    $nombrePais = mysqli_real_escape_string($conn, $nombrePais);
    $query = "INSERT INTO paises (nombre_pais) VALUES ('$nombrePais')";
    if (mysqli_query($conn, $query)) {
        return "País '$nombrePais' agregado correctamente";
    } else {
        return "Error al agregar país: " . mysqli_error($conn);
    }
}
?>
