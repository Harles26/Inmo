<header>
    <div class="header-content">
        <h1>Administración de Inmobiliaria</h1>
        <h2>Sistema de Administración Web Para Inmobiliaria</h2>
    </div>
</header>

<style>header {
    background-color: #2196f3; /* Azul más claro */
    color: #fff; /* Blanco */
    padding: 5px 0;
    text-align: center;
    line-height: 40px; /* Ajuste de la altura de línea para centrar verticalmente */

}

.header-content {
    max-width: 800px;
    margin: 0 auto;
}

h1 {
    font-size: 1.5em;
    margin-bottom: 10px;
}

h2 {
    font-size: 1.2em;
    font-weight: normal;
    margin-top: 0;
}


</style>