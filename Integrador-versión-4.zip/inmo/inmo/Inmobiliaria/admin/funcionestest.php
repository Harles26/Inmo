<?php
// funcionestest.php

include("fun.php");

function testObtenerConfiguracion($conn) {
    $config = obtenerConfiguracion($conn);
    if ($config['user'] != 'admin' || $config['password'] != '1234') {
        echo "Fallo en la prueba de obtenerConfiguracion: valores iniciales incorrectos\n";
        return false;
    }
    
    echo "Prueba de obtenerConfiguracion pasó correctamente\n";
    return true;
}

function testAgregarNuevoTipoDePropiedad($conn) {
    $mensaje = agregarNuevoTipoDePropiedad($conn, 'Casa');
    if (strpos($mensaje, 'correctamente') === false) {
        echo "Fallo en la prueba de agregarNuevoTipoDePropiedad\n";
        return false;
    }
    
    echo "Prueba de agregarNuevoTipoDePropiedad pasó correctamente\n";
    return true;
}

// Función de prueba para agregar un nuevo país
function testAgregarNuevoPais($conn) {
    $mensaje = agregarNuevoPais($conn, 'España');
    if (strpos($mensaje, 'correctamente') === false) {
        echo "Fallo en la prueba de agregarNuevoPais\n";
        return false;
    }
    
    echo "Prueba de agregarNuevoPais pasó correctamente\n";
    return true;
}

// Establecer la conexión a la base de datos
$conn = mysqli_connect("localhost", "root", "", "BD_INMOBILIARIA");
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Ejecutar las pruebas
testObtenerConfiguracion($conn);
testAgregarNuevoTipoDePropiedad($conn);
testAgregarNuevoPais($conn);

mysqli_close($conn);
?>
