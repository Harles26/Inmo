import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from scipy.sparse import csr_matrix

# 1. CARGA DE DATOS
df = pd.read_csv('dataset_inquilinos.csv', index_col='id_inquilino')

df.columns = [
    'horario', 'bioritmo', 'nivel_educativo', 'leer', 'animacion',
    'cine', 'mascotas', 'cocinar', 'deporte', 'dieta', 'fumador',
    'visitas', 'orden', 'musica_tipo', 'musica_alta', 'plan_perfecto', 'instrumento'
]

# 2. ONE HOT ENCODING
encoder = OneHotEncoder()
df_encoded = encoder.fit_transform(df)

# 3. MATRIZ DE SIMILITUD
matriz_s = df_encoded.dot(df_encoded.T)

# 4. REESCALAR MATRIZ DE SIMILITUD
rango_min = -100
rango_max = 100
min_original = matriz_s.min()
max_original = matriz_s.max()

# Convertir la matriz dispersa a una matriz densa
matriz_s_dense = matriz_s.toarray()

# Realizar la operación de reescalado en la matriz densa
matriz_s_reescalada_dense = ((matriz_s_dense - min_original) / (max_original - min_original)) * (rango_max - rango_min) + rango_min

# Convertir la matriz reescalada de nuevo a una matriz dispersa
matriz_s_reescalada = csr_matrix(matriz_s_reescalada_dense)

# 5. CONVERTIR A PANDAS DATAFRAME
df_similaridad = pd.DataFrame.sparse.from_spmatrix(
    matriz_s_reescalada,
    index=df.index,
    columns=df.index
)

# 6. BÚSQUEDA DE INQUILINOS COMPATIBLES
def inquilinos_compatibles(id_inquilinos, topn):
    # Verificar si todos los ID de inquilinos existen en la matriz de similaridad
    for id_inquilino in id_inquilinos:
        if id_inquilino not in df_similaridad.index:
            return 'Al menos uno de los inquilinos no encontrado'

    # Obtener las filas correspondientes a los inquilinos dados
    filas_inquilinos = df_similaridad.loc[id_inquilinos]

    # Calcular la similitud promedio entre los inquilinos
    similitud_promedio = filas_inquilinos.mean(axis=0)

    # Ordenar los inquilinos en función de su similitud promedio
    inquilinos_similares = similitud_promedio.sort_values(ascending=False)

    # Excluir los inquilinos de referencia (los que están en la lista)
    inquilinos_similares = inquilinos_similares.drop(id_inquilinos)

    # Tomar los topn inquilinos más similares
    topn_inquilinos = inquilinos_similares.head(topn)

    # Obtener los registros de los inquilinos similares
    registros_similares = df.loc[topn_inquilinos.index]

    # Obtener los registros de los inquilinos buscados
    registros_buscados = df.loc[id_inquilinos]

    # Concatenar los registros buscados con los registros similares en las columnas
    resultado = pd.concat([registros_buscados.T, registros_similares.T], axis=1)

    # Crear un objeto Series con la similitud de los inquilinos similares encontrados
    similitud_series = pd.Series(data=topn_inquilinos.values, index=topn_inquilinos.index, name='Similitud')

    # Devolver el resultado y el objeto Series
    return(resultado, similitud_series)

